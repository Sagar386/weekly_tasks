import unittest
from stack import Stack
from browser_history import BrowserHistory


class TestStack(unittest.TestCase):

    def test_push_pop(self):
        s = Stack()
        s.push("a")
        s.push("b")
        self.assertEqual(s.pop(), "b")
        self.assertEqual(s.pop(), "a")

    def test_peek(self):
        s = Stack()
        s.push(10)
        self.assertEqual(s.peek(), 10)
        self.assertEqual(s.size(), 1)

    def test_is_empty(self):
        s = Stack()
        self.assertTrue(s.is_empty())
        s.push(1)
        self.assertFalse(s.is_empty())

    def test_clear(self):
        s = Stack()
        s.push(1)
        s.push(2)
        s.clear()
        self.assertTrue(s.is_empty())
        self.assertEqual(s.size(), 0)

    def test_pop_empty_raises(self):
        s = Stack()
        with self.assertRaises(IndexError):
            s.pop()


class TestBrowserHistory(unittest.TestCase):

    def test_initial_page(self):
        browser = BrowserHistory("home.com")
        self.assertEqual(browser.get_current_page(), "home.com")

    def test_visit(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        self.assertEqual(browser.get_current_page(), "page1.com")

    def test_go_back(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        browser.visit("page2.com")
        browser.go_back()
        self.assertEqual(browser.get_current_page(), "page1.com")

    def test_go_back_to_start(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        browser.go_back()
        self.assertEqual(browser.get_current_page(), "home.com")

    def test_go_back_when_no_history(self):
        browser = BrowserHistory("home.com")
        browser.go_back()
        self.assertEqual(browser.get_current_page(), "home.com")

    def test_go_forward(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        browser.go_back()
        browser.go_forward()
        self.assertEqual(browser.get_current_page(), "page1.com")

    def test_go_forward_when_no_history(self):
        browser = BrowserHistory("home.com")
        browser.go_forward()
        self.assertEqual(browser.get_current_page(), "home.com")

    def test_visit_clears_forward(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        browser.visit("page2.com")
        browser.go_back()  # at page1, forward has page2
        browser.visit("page3.com")  # should clear forward
        self.assertFalse(browser.can_go_forward())

    def test_can_go_back(self):
        browser = BrowserHistory("home.com")
        self.assertFalse(browser.can_go_back())
        browser.visit("page1.com")
        self.assertTrue(browser.can_go_back())

    def test_can_go_forward(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        self.assertFalse(browser.can_go_forward())
        browser.go_back()
        self.assertTrue(browser.can_go_forward())

    def test_back_and_forward_multiple(self):
        browser = BrowserHistory("home.com")
        browser.visit("a.com")
        browser.visit("b.com")
        browser.visit("c.com")

        browser.go_back()
        browser.go_back()
        self.assertEqual(browser.get_current_page(), "a.com")

        browser.go_forward()
        self.assertEqual(browser.get_current_page(), "b.com")

        browser.go_forward()
        self.assertEqual(browser.get_current_page(), "c.com")

    def test_back_history_list(self):
        browser = BrowserHistory("home.com")
        browser.visit("a.com")
        browser.visit("b.com")
        history = browser.get_back_history()
        self.assertEqual(history, ["a.com", "home.com"])

    def test_forward_history_list(self):
        browser = BrowserHistory("home.com")
        browser.visit("a.com")
        browser.visit("b.com")
        browser.go_back()
        browser.go_back()
        forward = browser.get_forward_history()
        self.assertEqual(forward, ["a.com", "b.com"])

    def test_complex_navigation(self):
        browser = BrowserHistory("home.com")
        browser.visit("page1.com")
        browser.visit("page2.com")
        browser.go_back()           # at page1
        browser.visit("page3.com")  # forward cleared
        browser.go_back()           # at page1
        browser.go_back()           # at home
        self.assertEqual(browser.get_current_page(), "home.com")
        self.assertTrue(browser.can_go_forward())


if __name__ == "__main__":
    unittest.main()
