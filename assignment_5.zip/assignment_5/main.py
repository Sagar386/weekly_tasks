from browser_history import BrowserHistory


def run_demo():
    """Run a pre-defined demo showing how the browser history works."""
    print("=" * 50)
    print("BROWSER HISTORY SIMULATOR - DEMO")
    print("=" * 50)

    browser = BrowserHistory("google.com")
    print(f"\nStarting at: {browser.get_current_page()}")

    # visit some pages
    print("\n--- Visiting pages ---")
    browser.visit("python.org")
    print(f"Visited: python.org")
    browser.show_status()

    browser.visit("github.com")
    print(f"\nVisited: github.com")
    browser.show_status()

    browser.visit("stackoverflow.com")
    print(f"\nVisited: stackoverflow.com")
    browser.show_status()

    # go back
    print("\n--- Going back ---")
    page = browser.go_back()
    print(f"Went back to: {page}")
    browser.show_status()

    page = browser.go_back()
    print(f"\nWent back to: {page}")
    browser.show_status()

    # go forward
    print("\n--- Going forward ---")
    page = browser.go_forward()
    print(f"Went forward to: {page}")
    browser.show_status()

    # visit a new page (clears forward history)
    print("\n--- Visiting new page (clears forward history) ---")
    browser.visit("docs.python.org")
    print(f"Visited: docs.python.org")
    browser.show_status()
    print("  (Notice: forward history is now empty!)")


def run_interactive():
    """Run an interactive browser history session."""
    print("\n" + "=" * 50)
    print("BROWSER HISTORY - INTERACTIVE MODE")
    print("=" * 50)
    print("Commands: visit <url>, back, forward, status, quit")
    print()

    browser = BrowserHistory("homepage.com")
    print(f"Starting at: {browser.get_current_page()}\n")

    while True:
        command = input(">> ").strip().lower()

        if command == "quit" or command == "exit":
            print("Goodbye!")
            break
        elif command.startswith("visit "):
            url = command[6:].strip()
            if url:
                browser.visit(url)
                print(f"Visited: {url}")
            else:
                print("Please provide a URL. Example: visit google.com")
        elif command == "back":
            page = browser.go_back()
            print(f"Current page: {page}")
        elif command == "forward":
            page = browser.go_forward()
            print(f"Current page: {page}")
        elif command == "status":
            browser.show_status()
        elif command == "help":
            print("Commands: visit <url>, back, forward, status, quit")
        else:
            print("Unknown command. Type 'help' for commands.")


if __name__ == "__main__":
    run_demo()

    print("\n")
    try:
        run_interactive()
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye!")
