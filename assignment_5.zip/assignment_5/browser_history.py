from stack import Stack


class BrowserHistory:
    """
    Simulates browser navigation using two stacks.

    back_stack: holds pages we can go back to
    forward_stack: holds pages we can go forward to

    current_page: the page currently being viewed
    """

    def __init__(self, homepage="about:blank"):
        self.current_page = homepage
        self.back_stack = Stack()
        self.forward_stack = Stack()

    def visit(self, url):
        """Visit a new URL. Clears forward history."""
        self.back_stack.push(self.current_page)
        self.current_page = url
        self.forward_stack.clear()  # forward history is lost when visiting new page

    def go_back(self):
        """Go back to the previous page."""
        if self.back_stack.is_empty():
            print("Cannot go back - no previous pages.")
            return self.current_page

        self.forward_stack.push(self.current_page)
        self.current_page = self.back_stack.pop()
        return self.current_page

    def go_forward(self):
        """Go forward to the next page."""
        if self.forward_stack.is_empty():
            print("Cannot go forward - no forward pages.")
            return self.current_page

        self.back_stack.push(self.current_page)
        self.current_page = self.forward_stack.pop()
        return self.current_page

    def get_current_page(self):
        return self.current_page

    def can_go_back(self):
        return not self.back_stack.is_empty()

    def can_go_forward(self):
        return not self.forward_stack.is_empty()

    def get_back_history(self):
        """Return list of pages in back history (most recent first)."""
        return self.back_stack.to_list()

    def get_forward_history(self):
        """Return list of pages in forward history (next first)."""
        return self.forward_stack.to_list()

    def show_status(self):
        print(f"\n  Current page: {self.current_page}")
        if not self.back_stack.is_empty():
            print(f"  Back history:    {self.back_stack.to_list()}")
        else:
            print(f"  Back history:    (empty)")
        if not self.forward_stack.is_empty():
            print(f"  Forward history: {self.forward_stack.to_list()}")
        else:
            print(f"  Forward history: (empty)")
