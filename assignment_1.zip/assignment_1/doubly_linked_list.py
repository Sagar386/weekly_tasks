class DNode:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None


class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self._size = 0

    def insert_at_head(self, data):
        new_node = DNode(data)

        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

        self._size += 1

    def insert_at_tail(self, data):
        new_node = DNode(data)

        if self.tail is None:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node

        self._size += 1

    def delete(self, value):
        current = self.head

        while current is not None:
            if current.data == value:
                # if it's the only node
                if current.prev is None and current.next is None:
                    self.head = None
                    self.tail = None
                # if it's the head
                elif current.prev is None:
                    self.head = current.next
                    self.head.prev = None
                # if it's the tail
                elif current.next is None:
                    self.tail = current.prev
                    self.tail.next = None
                # somewhere in the middle
                else:
                    current.prev.next = current.next
                    current.next.prev = current.prev

                self._size -= 1
                return

            current = current.next

        raise ValueError(f"Value {value} not found in the list")

    def forward_traversal(self):
        result = []
        current = self.head
        while current is not None:
            result.append(current.data)
            current = current.next
        return result

    def backward_traversal(self):
        result = []
        current = self.tail
        while current is not None:
            result.append(current.data)
            current = current.prev
        return result

    def size(self):
        return self._size

    def __str__(self):
        if self.head is None:
            return "Empty List"

        parts = []
        current = self.head
        while current is not None:
            parts.append(str(current.data))
            current = current.next
        return " <-> ".join(parts)
