class DynamicArray:
    """A resizable array that grows and shrinks automatically."""

    def __init__(self, initial_capacity=4):
        self._capacity = initial_capacity
        self._size = 0
        self._data = [None] * self._capacity

    def append(self, value):
        if self._size == self._capacity:
            self._resize(self._capacity * 2)
        self._data[self._size] = value
        self._size += 1

    def insert(self, index, value):
        if index < 0 or index > self._size:
            raise IndexError("Index out of range")

        if self._size == self._capacity:
            self._resize(self._capacity * 2)

        # shift elements to the right to make space
        for i in range(self._size, index, -1):
            self._data[i] = self._data[i - 1]

        self._data[index] = value
        self._size += 1

    def delete(self, index):
        if index < 0 or index >= self._size:
            raise IndexError("Index out of range")

        removed = self._data[index]

        # shift elements to the left to fill the gap
        for i in range(index, self._size - 1):
            self._data[i] = self._data[i + 1]

        self._data[self._size - 1] = None
        self._size -= 1

        # shrink if only 25% is used (but never go below 4)
        if self._size > 0 and self._size <= self._capacity // 4 and self._capacity > 4:
            self._resize(self._capacity // 2)

        return removed

    def get(self, index):
        if index < 0 or index >= self._size:
            raise IndexError("Index out of range")
        return self._data[index]

    def set(self, index, value):
        if index < 0 or index >= self._size:
            raise IndexError("Index out of range")
        self._data[index] = value

    def size(self):
        return self._size

    def capacity(self):
        return self._capacity

    def _resize(self, new_capacity):
        new_data = [None] * new_capacity
        for i in range(self._size):
            new_data[i] = self._data[i]
        self._data = new_data
        self._capacity = new_capacity

    def __str__(self):
        items = []
        for i in range(self._size):
            items.append(str(self._data[i]))
        return "[" + ", ".join(items) + "]"

    def __len__(self):
        return self._size
