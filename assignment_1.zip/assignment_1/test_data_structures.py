import unittest
from dynamic_array import DynamicArray
from singly_linked_list import SinglyLinkedList
from doubly_linked_list import DoublyLinkedList


class TestDynamicArray(unittest.TestCase):

    def test_append_and_get(self):
        arr = DynamicArray()
        arr.append(10)
        arr.append(20)
        arr.append(30)
        self.assertEqual(arr.get(0), 10)
        self.assertEqual(arr.get(1), 20)
        self.assertEqual(arr.get(2), 30)

    def test_size_and_capacity(self):
        arr = DynamicArray(initial_capacity=2)
        self.assertEqual(arr.size(), 0)
        self.assertEqual(arr.capacity(), 2)
        arr.append(1)
        arr.append(2)
        arr.append(3)  # should trigger resize
        self.assertEqual(arr.size(), 3)
        self.assertEqual(arr.capacity(), 4)

    def test_insert_at_beginning(self):
        arr = DynamicArray()
        arr.append(2)
        arr.append(3)
        arr.insert(0, 1)
        self.assertEqual(arr.get(0), 1)
        self.assertEqual(arr.get(1), 2)

    def test_insert_at_middle(self):
        arr = DynamicArray()
        arr.append(1)
        arr.append(3)
        arr.insert(1, 2)
        self.assertEqual(arr.get(1), 2)
        self.assertEqual(arr.size(), 3)

    def test_insert_invalid_index(self):
        arr = DynamicArray()
        with self.assertRaises(IndexError):
            arr.insert(5, 10)

    def test_delete(self):
        arr = DynamicArray()
        arr.append(10)
        arr.append(20)
        arr.append(30)
        removed = arr.delete(1)
        self.assertEqual(removed, 20)
        self.assertEqual(arr.size(), 2)
        self.assertEqual(arr.get(1), 30)

    def test_delete_invalid_index(self):
        arr = DynamicArray()
        arr.append(1)
        with self.assertRaises(IndexError):
            arr.delete(5)

    def test_set_value(self):
        arr = DynamicArray()
        arr.append(10)
        arr.set(0, 99)
        self.assertEqual(arr.get(0), 99)

    def test_resize_doubles_capacity(self):
        arr = DynamicArray(initial_capacity=2)
        arr.append(1)
        arr.append(2)
        self.assertEqual(arr.capacity(), 2)
        arr.append(3)
        self.assertEqual(arr.capacity(), 4)

    def test_shrink_on_delete(self):
        arr = DynamicArray(initial_capacity=4)
        for i in range(8):
            arr.append(i)
        # capacity should be 8 now
        self.assertEqual(arr.capacity(), 8)
        # delete down to 2 elements (25% of 8)
        for i in range(6):
            arr.delete(0)
        self.assertEqual(arr.size(), 2)
        self.assertTrue(arr.capacity() < 8)

    def test_get_out_of_range(self):
        arr = DynamicArray()
        with self.assertRaises(IndexError):
            arr.get(0)

    def test_str_representation(self):
        arr = DynamicArray()
        arr.append(1)
        arr.append(2)
        self.assertEqual(str(arr), "[1, 2]")


class TestSinglyLinkedList(unittest.TestCase):

    def test_insert_at_head(self):
        sll = SinglyLinkedList()
        sll.insert_at_head(3)
        sll.insert_at_head(2)
        sll.insert_at_head(1)
        self.assertEqual(sll.to_list(), [1, 2, 3])

    def test_insert_at_tail(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        sll.insert_at_tail(2)
        sll.insert_at_tail(3)
        self.assertEqual(sll.to_list(), [1, 2, 3])

    def test_delete_head(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        sll.insert_at_tail(2)
        sll.delete(1)
        self.assertEqual(sll.to_list(), [2])

    def test_delete_middle(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        sll.insert_at_tail(2)
        sll.insert_at_tail(3)
        sll.delete(2)
        self.assertEqual(sll.to_list(), [1, 3])

    def test_delete_from_empty_list(self):
        sll = SinglyLinkedList()
        with self.assertRaises(ValueError):
            sll.delete(10)

    def test_delete_not_found(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        with self.assertRaises(ValueError):
            sll.delete(99)

    def test_search_found(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(10)
        sll.insert_at_tail(20)
        sll.insert_at_tail(30)
        self.assertEqual(sll.search(20), 1)

    def test_search_not_found(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(10)
        self.assertEqual(sll.search(99), -1)

    def test_reverse(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        sll.insert_at_tail(2)
        sll.insert_at_tail(3)
        sll.reverse()
        self.assertEqual(sll.to_list(), [3, 2, 1])

    def test_reverse_empty(self):
        sll = SinglyLinkedList()
        sll.reverse()
        self.assertEqual(sll.to_list(), [])

    def test_size(self):
        sll = SinglyLinkedList()
        self.assertEqual(sll.size(), 0)
        sll.insert_at_tail(1)
        sll.insert_at_tail(2)
        self.assertEqual(sll.size(), 2)

    def test_single_node_delete(self):
        sll = SinglyLinkedList()
        sll.insert_at_head(5)
        sll.delete(5)
        self.assertEqual(sll.size(), 0)
        self.assertEqual(sll.to_list(), [])

    def test_duplicate_values(self):
        sll = SinglyLinkedList()
        sll.insert_at_tail(1)
        sll.insert_at_tail(1)
        sll.insert_at_tail(1)
        sll.delete(1)  # should delete first occurrence
        self.assertEqual(sll.to_list(), [1, 1])


class TestDoublyLinkedList(unittest.TestCase):

    def test_insert_at_head(self):
        dll = DoublyLinkedList()
        dll.insert_at_head(3)
        dll.insert_at_head(2)
        dll.insert_at_head(1)
        self.assertEqual(dll.forward_traversal(), [1, 2, 3])

    def test_insert_at_tail(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(1)
        dll.insert_at_tail(2)
        dll.insert_at_tail(3)
        self.assertEqual(dll.forward_traversal(), [1, 2, 3])

    def test_forward_traversal(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(10)
        dll.insert_at_tail(20)
        dll.insert_at_tail(30)
        self.assertEqual(dll.forward_traversal(), [10, 20, 30])

    def test_backward_traversal(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(10)
        dll.insert_at_tail(20)
        dll.insert_at_tail(30)
        self.assertEqual(dll.backward_traversal(), [30, 20, 10])

    def test_delete_head(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(1)
        dll.insert_at_tail(2)
        dll.insert_at_tail(3)
        dll.delete(1)
        self.assertEqual(dll.forward_traversal(), [2, 3])

    def test_delete_tail(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(1)
        dll.insert_at_tail(2)
        dll.insert_at_tail(3)
        dll.delete(3)
        self.assertEqual(dll.forward_traversal(), [1, 2])
        self.assertEqual(dll.backward_traversal(), [2, 1])

    def test_delete_middle(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(1)
        dll.insert_at_tail(2)
        dll.insert_at_tail(3)
        dll.delete(2)
        self.assertEqual(dll.forward_traversal(), [1, 3])

    def test_delete_only_node(self):
        dll = DoublyLinkedList()
        dll.insert_at_head(5)
        dll.delete(5)
        self.assertEqual(dll.size(), 0)
        self.assertEqual(dll.forward_traversal(), [])

    def test_delete_not_found(self):
        dll = DoublyLinkedList()
        dll.insert_at_tail(1)
        with self.assertRaises(ValueError):
            dll.delete(99)

    def test_size(self):
        dll = DoublyLinkedList()
        self.assertEqual(dll.size(), 0)
        dll.insert_at_tail(1)
        dll.insert_at_tail(2)
        self.assertEqual(dll.size(), 2)
        dll.delete(1)
        self.assertEqual(dll.size(), 1)


if __name__ == "__main__":
    unittest.main()
