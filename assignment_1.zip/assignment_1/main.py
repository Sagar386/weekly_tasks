from dynamic_array import DynamicArray
from singly_linked_list import SinglyLinkedList
from doubly_linked_list import DoublyLinkedList


def demo_dynamic_array():
    print("=" * 50)
    print("DYNAMIC ARRAY DEMO")
    print("=" * 50)

    arr = DynamicArray(initial_capacity=2)
    print(f"Created array with capacity: {arr.capacity()}")

    # appending elements
    for val in [10, 20, 30, 40, 50]:
        arr.append(val)
        print(f"Appended {val} -> {arr} (size={arr.size()}, capacity={arr.capacity()})")

    # inserting at index
    arr.insert(2, 25)
    print(f"\nInserted 25 at index 2 -> {arr}")

    # getting and setting
    print(f"Element at index 3: {arr.get(3)}")
    arr.set(3, 35)
    print(f"Set index 3 to 35 -> {arr}")

    # deleting
    removed = arr.delete(0)
    print(f"\nDeleted index 0 (was {removed}) -> {arr}")

    print()


def demo_singly_linked_list():
    print("=" * 50)
    print("SINGLY LINKED LIST DEMO")
    print("=" * 50)

    sll = SinglyLinkedList()

    # inserting elements
    sll.insert_at_tail(10)
    sll.insert_at_tail(20)
    sll.insert_at_tail(30)
    sll.insert_at_head(5)
    print(f"After insertions: {sll}")
    print(f"Size: {sll.size()}")

    # searching
    idx = sll.search(20)
    print(f"Search for 20: found at index {idx}")
    idx = sll.search(99)
    print(f"Search for 99: {'found at index ' + str(idx) if idx != -1 else 'not found'}")

    # deleting
    sll.delete(20)
    print(f"After deleting 20: {sll}")

    # reversing
    sll.reverse()
    print(f"After reversing: {sll}")

    print()


def demo_doubly_linked_list():
    print("=" * 50)
    print("DOUBLY LINKED LIST DEMO")
    print("=" * 50)

    dll = DoublyLinkedList()

    dll.insert_at_tail(10)
    dll.insert_at_tail(20)
    dll.insert_at_tail(30)
    dll.insert_at_head(5)
    print(f"After insertions: {dll}")

    print(f"Forward traversal:  {dll.forward_traversal()}")
    print(f"Backward traversal: {dll.backward_traversal()}")

    dll.delete(20)
    print(f"After deleting 20: {dll}")
    print(f"Forward:  {dll.forward_traversal()}")
    print(f"Backward: {dll.backward_traversal()}")

    print()


if __name__ == "__main__":
    demo_dynamic_array()
    demo_singly_linked_list()
    demo_doubly_linked_list()

    print("=" * 50)
    print("DLL vs SLL - When to use which?")
    print("=" * 50)
    print("- Use SLL when you only need forward traversal (saves memory)")
    print("- Use DLL when you need both forward and backward traversal")
    print("- DLL is better for deletion if you have a reference to the node")
    print("- SLL uses less memory (no prev pointer)")
