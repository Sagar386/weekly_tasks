class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None
        self._size = 0

    def insert_at_head(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node
        self._size += 1

    def insert_at_tail(self, data):
        new_node = Node(data)

        if self.head is None:
            self.head = new_node
            self._size += 1
            return

        current = self.head
        while current.next is not None:
            current = current.next
        current.next = new_node
        self._size += 1

    def delete(self, value):
        if self.head is None:
            raise ValueError(f"Value {value} not found in the list")

        # if the head node holds the value
        if self.head.data == value:
            self.head = self.head.next
            self._size -= 1
            return

        current = self.head
        while current.next is not None:
            if current.next.data == value:
                current.next = current.next.next
                self._size -= 1
                return
            current = current.next

        raise ValueError(f"Value {value} not found in the list")

    def search(self, value):
        current = self.head
        index = 0
        while current is not None:
            if current.data == value:
                return index
            current = current.next
            index += 1
        return -1

    def reverse(self):
        prev = None
        current = self.head
        while current is not None:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev

    def size(self):
        return self._size

    def to_list(self):
        result = []
        current = self.head
        while current is not None:
            result.append(current.data)
            current = current.next
        return result

    def __str__(self):
        if self.head is None:
            return "Empty List"

        parts = []
        current = self.head
        while current is not None:
            parts.append(str(current.data))
            current = current.next
        return " -> ".join(parts)
