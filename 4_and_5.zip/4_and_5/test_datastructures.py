import unittest
from datastructures.stack import Stack
from datastructures.queue import Queue
from datastructures.lru_cache import LRUCache
from datastructures.exceptions import EmptyStructureError, CapacityError


class TestStack(unittest.TestCase):
    def setUp(self):
        self.stack = Stack()

    def test_push_and_pop(self):
        self.stack.push(10)
        self.stack.push(20)
        self.assertEqual(self.stack.pop(), 20)
        self.assertEqual(self.stack.pop(), 10)

    def test_peek(self):
        self.stack.push(42)
        self.assertEqual(self.stack.peek(), 42)
        self.assertEqual(self.stack.size(), 1)  # peek should not remove

    def test_is_empty_on_new_stack(self):
        self.assertTrue(self.stack.is_empty())

    def test_is_empty_after_push(self):
        self.stack.push(1)
        self.assertFalse(self.stack.is_empty())

    def test_size(self):
        self.assertEqual(self.stack.size(), 0)
        self.stack.push("a")
        self.stack.push("b")
        self.assertEqual(self.stack.size(), 2)

    def test_pop_empty_raises(self):
        with self.assertRaises(EmptyStructureError):
            self.stack.pop()

    def test_peek_empty_raises(self):
        with self.assertRaises(EmptyStructureError):
            self.stack.peek()

    def test_lifo_order(self):
        for i in range(5):
            self.stack.push(i)
        result = [self.stack.pop() for _ in range(5)]
        self.assertEqual(result, [4, 3, 2, 1, 0])

    def test_push_pop_mixed(self):
        self.stack.push(1)
        self.stack.push(2)
        self.assertEqual(self.stack.pop(), 2)
        self.stack.push(3)
        self.assertEqual(self.stack.pop(), 3)
        self.assertEqual(self.stack.pop(), 1)

    def test_str_representation(self):
        self.stack.push(10)
        self.assertIn("10", str(self.stack))

    def test_contains(self):
        self.stack.push(5)
        self.stack.push(10)
        self.assertIn(5, self.stack)
        self.assertNotIn(99, self.stack)

    def test_len(self):
        self.stack.push(1)
        self.stack.push(2)
        self.assertEqual(len(self.stack), 2)


class TestQueue(unittest.TestCase):
    def setUp(self):
        self.queue = Queue()

    def test_enqueue_and_dequeue(self):
        self.queue.enqueue(10)
        self.queue.enqueue(20)
        self.assertEqual(self.queue.dequeue(), 10)
        self.assertEqual(self.queue.dequeue(), 20)

    def test_front(self):
        self.queue.enqueue(42)
        self.assertEqual(self.queue.front(), 42)
        self.assertEqual(self.queue.size(), 1)  # front should not remove

    def test_is_empty_on_new_queue(self):
        self.assertTrue(self.queue.is_empty())

    def test_is_empty_after_enqueue(self):
        self.queue.enqueue(1)
        self.assertFalse(self.queue.is_empty())

    def test_size(self):
        self.assertEqual(self.queue.size(), 0)
        self.queue.enqueue("a")
        self.queue.enqueue("b")
        self.assertEqual(self.queue.size(), 2)

    def test_dequeue_empty_raises(self):
        with self.assertRaises(EmptyStructureError):
            self.queue.dequeue()

    def test_front_empty_raises(self):
        with self.assertRaises(EmptyStructureError):
            self.queue.front()

    def test_fifo_order(self):
        for i in range(5):
            self.queue.enqueue(i)
        result = [self.queue.dequeue() for _ in range(5)]
        self.assertEqual(result, [0, 1, 2, 3, 4])

    def test_enqueue_dequeue_mixed(self):
        self.queue.enqueue(1)
        self.queue.enqueue(2)
        self.assertEqual(self.queue.dequeue(), 1)
        self.queue.enqueue(3)
        self.assertEqual(self.queue.dequeue(), 2)
        self.assertEqual(self.queue.dequeue(), 3)

    def test_str_representation(self):
        self.queue.enqueue(10)
        self.assertIn("10", str(self.queue))

    def test_contains(self):
        self.queue.enqueue(5)
        self.queue.enqueue(10)
        self.assertIn(5, self.queue)
        self.assertNotIn(99, self.queue)

    def test_len(self):
        self.queue.enqueue(1)
        self.queue.enqueue(2)
        self.assertEqual(len(self.queue), 2)

    def test_dequeue_does_not_contain_removed(self):
        self.queue.enqueue(1)
        self.queue.enqueue(2)
        self.queue.dequeue()
        self.assertNotIn(1, self.queue)


class TestLRUCache(unittest.TestCase):
    def setUp(self):
        self.cache = LRUCache(3)

    def test_put_and_get(self):
        self.cache.put("a", 1)
        self.assertEqual(self.cache.get("a"), 1)

    def test_get_missing_key_returns_none(self):
        self.assertIsNone(self.cache.get("missing"))

    def test_evicts_least_recently_used(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.cache.put("c", 3)
        # Cache is full: [c, b, a]. Adding "d" should evict "a"
        self.cache.put("d", 4)
        self.assertIsNone(self.cache.get("a"))
        self.assertEqual(self.cache.get("d"), 4)

    def test_get_updates_recently_used(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.cache.put("c", 3)
        # Access "a" -- now "a" is most recent. LRU is "b"
        self.cache.get("a")
        self.cache.put("d", 4)  # evicts "b" (least recently used)
        self.assertIsNone(self.cache.get("b"))
        self.assertEqual(self.cache.get("a"), 1)

    def test_update_existing_key(self):
        self.cache.put("a", 1)
        self.cache.put("a", 100)
        self.assertEqual(self.cache.get("a"), 100)
        self.assertEqual(self.cache.size(), 1)

    def test_size(self):
        self.assertEqual(self.cache.size(), 0)
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.assertEqual(self.cache.size(), 2)

    def test_capacity_property(self):
        self.assertEqual(self.cache.capacity, 3)

    def test_invalid_capacity_raises(self):
        with self.assertRaises(CapacityError):
            LRUCache(0)
        with self.assertRaises(CapacityError):
            LRUCache(-5)

    def test_contains(self):
        self.cache.put("x", 10)
        self.assertIn("x", self.cache)
        self.assertNotIn("y", self.cache)

    def test_str_shows_items(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        result = str(self.cache)
        self.assertIn("a:1", result)
        self.assertIn("b:2", result)

    def test_cache_capacity_one(self):
        small = LRUCache(1)
        small.put("a", 1)
        small.put("b", 2)  # evicts "a"
        self.assertIsNone(small.get("a"))
        self.assertEqual(small.get("b"), 2)

    def test_eviction_order_with_multiple_puts(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.cache.put("c", 3)
        # Update "a" (moves to front). LRU order: a(front), c, b(tail)
        self.cache.put("a", 10)
        self.cache.put("d", 4)  # evicts "b"
        self.assertIsNone(self.cache.get("b"))
        self.assertEqual(self.cache.get("a"), 10)
        self.assertEqual(self.cache.get("c"), 3)
        self.assertEqual(self.cache.get("d"), 4)


if __name__ == "__main__":
    unittest.main()
