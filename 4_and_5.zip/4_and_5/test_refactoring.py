import unittest
from refactoring.student import Student
from refactoring.grade import Grade
from refactoring.grade_manager import GradeManager
from refactoring.exceptions import (
    StudentNotFoundException,
    InvalidScoreError,
    SubjectNotFoundException,
)


class TestStudent(unittest.TestCase):
    def test_student_properties(self):
        s = Student(1, "Alice", 20, "alice@email.com")
        self.assertEqual(s.student_id, 1)
        self.assertEqual(s.name, "Alice")
        self.assertEqual(s.age, 20)
        self.assertEqual(s.email, "alice@email.com")

    def test_student_str(self):
        s = Student(1, "Alice", 20, "alice@email.com")
        self.assertIn("Alice", str(s))
        self.assertIn("1", str(s))

    def test_student_equality(self):
        s1 = Student(1, "Alice", 20, "a@b.com")
        s2 = Student(1, "Alice Clone", 25, "c@d.com")
        self.assertEqual(s1, s2)

    def test_student_inequality(self):
        s1 = Student(1, "Alice", 20, "a@b.com")
        s2 = Student(2, "Bob", 21, "b@c.com")
        self.assertNotEqual(s1, s2)


class TestGrade(unittest.TestCase):
    def test_grade_properties(self):
        g = Grade("Math", 85)
        self.assertEqual(g.subject, "Math")
        self.assertEqual(g.score, 85)

    def test_grade_str(self):
        g = Grade("Math", 85)
        self.assertIn("Math", str(g))
        self.assertIn("85", str(g))

    def test_invalid_score_too_high(self):
        with self.assertRaises(InvalidScoreError):
            Grade("Math", 101)

    def test_invalid_score_negative(self):
        with self.assertRaises(InvalidScoreError):
            Grade("Math", -5)

    def test_score_to_letter_A(self):
        self.assertEqual(Grade.score_to_letter(95), "A")

    def test_score_to_letter_B(self):
        self.assertEqual(Grade.score_to_letter(85), "B")

    def test_score_to_letter_C(self):
        self.assertEqual(Grade.score_to_letter(75), "C")

    def test_score_to_letter_D(self):
        self.assertEqual(Grade.score_to_letter(65), "D")

    def test_score_to_letter_F(self):
        self.assertEqual(Grade.score_to_letter(50), "F")

    def test_score_boundary_90(self):
        self.assertEqual(Grade.score_to_letter(90), "A")

    def test_update_score(self):
        g = Grade("Math", 70)
        g.score = 95
        self.assertEqual(g.score, 95)

    def test_update_score_invalid(self):
        g = Grade("Math", 70)
        with self.assertRaises(InvalidScoreError):
            g.score = 150


class TestGradeManager(unittest.TestCase):
    def setUp(self):
        self.manager = GradeManager()
        self.alice = self.manager.add_student("Alice", 20, "alice@email.com")
        self.bob = self.manager.add_student("Bob", 21, "bob@email.com")

    def test_add_student(self):
        self.assertEqual(self.alice.name, "Alice")
        self.assertEqual(len(self.manager.list_students()), 2)

    def test_remove_student(self):
        self.manager.remove_student(self.alice.student_id)
        self.assertEqual(len(self.manager.list_students()), 1)

    def test_remove_nonexistent_raises(self):
        with self.assertRaises(StudentNotFoundException):
            self.manager.remove_student(999)

    def test_get_student(self):
        found = self.manager.get_student(self.alice.student_id)
        self.assertEqual(found.name, "Alice")

    def test_get_nonexistent_student_raises(self):
        with self.assertRaises(StudentNotFoundException):
            self.manager.get_student(999)

    def test_add_and_get_grades(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.alice.student_id, "Science", 80)
        grades = self.manager.get_student_grades(self.alice.student_id)
        self.assertEqual(len(grades), 2)

    def test_student_average(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.alice.student_id, "Science", 80)
        self.assertEqual(self.manager.get_student_average(self.alice.student_id), 85.0)

    def test_student_average_no_grades(self):
        self.assertEqual(self.manager.get_student_average(self.alice.student_id), 0.0)

    def test_grade_letter(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.alice.student_id, "Science", 80)
        self.assertEqual(self.manager.get_grade_letter(self.alice.student_id), "B")

    def test_update_score(self):
        self.manager.add_grade(self.alice.student_id, "Math", 70)
        self.manager.update_score(self.alice.student_id, "Math", 95)
        grades = self.manager.get_student_grades(self.alice.student_id)
        self.assertEqual(grades[0].score, 95)

    def test_update_score_nonexistent_subject(self):
        self.manager.add_grade(self.alice.student_id, "Math", 70)
        with self.assertRaises(SubjectNotFoundException):
            self.manager.update_score(self.alice.student_id, "Art", 80)

    def test_top_student(self):
        self.manager.add_grade(self.alice.student_id, "Math", 95)
        self.manager.add_grade(self.bob.student_id, "Math", 70)
        top = self.manager.get_top_student()
        self.assertEqual(top.name, "Alice")

    def test_top_student_empty(self):
        mgr = GradeManager()
        self.assertIsNone(mgr.get_top_student())

    def test_failing_students(self):
        self.manager.add_grade(self.alice.student_id, "Math", 95)
        self.manager.add_grade(self.bob.student_id, "Math", 40)
        failing = self.manager.get_failing_students()
        self.assertEqual(len(failing), 1)
        self.assertEqual(failing[0].name, "Bob")

    def test_subject_average(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.bob.student_id, "Math", 70)
        self.assertEqual(self.manager.get_subject_average("Math"), 80.0)

    def test_class_average(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.bob.student_id, "Math", 70)
        self.assertEqual(self.manager.get_class_average(), 80.0)

    def test_class_average_empty(self):
        mgr = GradeManager()
        self.assertEqual(mgr.get_class_average(), 0.0)

    def test_search_by_name(self):
        results = self.manager.search_by_name("ali")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "Alice")

    def test_search_by_name_no_match(self):
        results = self.manager.search_by_name("xyz")
        self.assertEqual(len(results), 0)

    def test_get_all_subjects(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        self.manager.add_grade(self.alice.student_id, "Science", 80)
        subjects = self.manager.get_all_subjects()
        self.assertEqual(subjects, ["Math", "Science"])

    def test_count_by_grade(self):
        self.manager.add_grade(self.alice.student_id, "Math", 95)
        self.manager.add_grade(self.bob.student_id, "Math", 45)
        counts = self.manager.count_by_grade()
        self.assertEqual(counts["A"], 1)
        self.assertEqual(counts["F"], 1)

    def test_student_report(self):
        self.manager.add_grade(self.alice.student_id, "Math", 90)
        report = self.manager.get_student_report(self.alice.student_id)
        self.assertIn("Alice", report)
        self.assertIn("Math", report)
        self.assertIn("90", report)

    def test_add_grade_invalid_score(self):
        with self.assertRaises(InvalidScoreError):
            self.manager.add_grade(self.alice.student_id, "Math", 150)

    def test_add_grade_nonexistent_student(self):
        with self.assertRaises(StudentNotFoundException):
            self.manager.add_grade(999, "Math", 80)


if __name__ == "__main__":
    unittest.main()
