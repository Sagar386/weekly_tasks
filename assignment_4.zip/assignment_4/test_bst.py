import unittest
from bst import BinarySearchTree


class TestBST(unittest.TestCase):

    def setUp(self):
        self.bst = BinarySearchTree()
        for val in [50, 30, 70, 20, 40, 60, 80]:
            self.bst.insert(val)

    def test_insert_and_search(self):
        self.assertTrue(self.bst.search(50))
        self.assertTrue(self.bst.search(30))
        self.assertTrue(self.bst.search(80))

    def test_search_not_found(self):
        self.assertFalse(self.bst.search(99))
        self.assertFalse(self.bst.search(0))

    def test_inorder(self):
        self.assertEqual(self.bst.inorder(), [20, 30, 40, 50, 60, 70, 80])

    def test_preorder(self):
        self.assertEqual(self.bst.preorder(), [50, 30, 20, 40, 70, 60, 80])

    def test_postorder(self):
        self.assertEqual(self.bst.postorder(), [20, 40, 30, 60, 80, 70, 50])

    def test_find_min(self):
        self.assertEqual(self.bst.find_min(), 20)

    def test_find_max(self):
        self.assertEqual(self.bst.find_max(), 80)

    def test_height(self):
        self.assertEqual(self.bst.height(), 2)

    def test_delete_leaf(self):
        self.bst.delete(20)
        self.assertFalse(self.bst.search(20))
        self.assertEqual(self.bst.inorder(), [30, 40, 50, 60, 70, 80])

    def test_delete_node_one_child(self):
        # delete 30 which has children 20 and 40
        b = BinarySearchTree()
        for val in [50, 30, 70, 20]:
            b.insert(val)
        b.delete(30)  # 30 has only left child (20)
        self.assertFalse(b.search(30))
        self.assertTrue(b.search(20))

    def test_delete_node_two_children(self):
        self.bst.delete(30)  # 30 has children 20 and 40
        self.assertFalse(self.bst.search(30))
        self.assertTrue(self.bst.search(20))
        self.assertTrue(self.bst.search(40))

    def test_delete_root(self):
        self.bst.delete(50)
        self.assertFalse(self.bst.search(50))
        # tree should still be valid
        inorder = self.bst.inorder()
        self.assertEqual(inorder, sorted(inorder))

    def test_delete_not_found(self):
        with self.assertRaises(ValueError):
            self.bst.delete(999)

    def test_is_valid_bst(self):
        self.assertTrue(self.bst.is_valid_bst())

    def test_duplicate_insert_ignored(self):
        self.bst.insert(50)  # already exists
        # inorder should not have duplicates
        self.assertEqual(self.bst.inorder(), [20, 30, 40, 50, 60, 70, 80])

    def test_empty_tree(self):
        empty = BinarySearchTree()
        self.assertFalse(empty.search(1))
        self.assertEqual(empty.inorder(), [])
        self.assertEqual(empty.height(), -1)

    def test_empty_tree_min_max(self):
        empty = BinarySearchTree()
        with self.assertRaises(ValueError):
            empty.find_min()
        with self.assertRaises(ValueError):
            empty.find_max()

    def test_single_element(self):
        b = BinarySearchTree()
        b.insert(42)
        self.assertTrue(b.search(42))
        self.assertEqual(b.height(), 0)
        self.assertEqual(b.find_min(), 42)
        self.assertEqual(b.find_max(), 42)

    def test_height_after_insertions(self):
        b = BinarySearchTree()
        b.insert(10)
        self.assertEqual(b.height(), 0)
        b.insert(5)
        self.assertEqual(b.height(), 1)
        b.insert(3)
        self.assertEqual(b.height(), 2)


if __name__ == "__main__":
    unittest.main()
