from bst import BinarySearchTree


def main():
    print("=" * 50)
    print("BINARY SEARCH TREE DEMO")
    print("=" * 50)

    bst = BinarySearchTree()

    # inserting values
    values = [50, 30, 70, 20, 40, 60, 80]
    print(f"\nInserting values: {values}")
    for val in values:
        bst.insert(val)

    # tree structure (visual)
    print("""
    Tree structure:
            50
           /  \\
         30    70
        /  \\  /  \\
       20  40 60  80
    """)

    # traversals
    print(f"Inorder traversal:   {bst.inorder()}")
    print(f"Preorder traversal:  {bst.preorder()}")
    print(f"Postorder traversal: {bst.postorder()}")

    # searching
    print(f"\nSearch for 40: {bst.search(40)}")
    print(f"Search for 99: {bst.search(99)}")

    # min, max, height
    print(f"\nMinimum value: {bst.find_min()}")
    print(f"Maximum value: {bst.find_max()}")
    print(f"Tree height:   {bst.height()}")

    # validate BST
    print(f"Is valid BST:  {bst.is_valid_bst()}")

    # deleting
    print("\n--- Deletion demo ---")

    # delete leaf
    print(f"\nDeleting 20 (leaf node):")
    bst.delete(20)
    print(f"  Inorder: {bst.inorder()}")

    # delete node with one child
    print(f"\nDeleting 30 (node with one child - 40):")
    bst.delete(30)
    print(f"  Inorder: {bst.inorder()}")

    # delete node with two children
    print(f"\nDeleting 70 (node with two children - 60, 80):")
    bst.delete(70)
    print(f"  Inorder: {bst.inorder()}")

    print(f"\nFinal tree is still valid BST: {bst.is_valid_bst()}")

    # duplicate handling
    print("\n--- Duplicate handling ---")
    bst2 = BinarySearchTree()
    bst2.insert(10)
    bst2.insert(10)  # duplicate - ignored
    print(f"Inserted 10 twice, inorder: {bst2.inorder()}")
    print("Rule: Duplicates are ignored (not inserted again)")


if __name__ == "__main__":
    main()
