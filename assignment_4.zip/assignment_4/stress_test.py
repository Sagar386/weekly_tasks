import time
import random
from bst import BinarySearchTree


def test_sequential_insertion():
    print("=" * 60)
    print("SEQUENTIAL INSERTION TEST (1 to 10,000)")
    print("=" * 60)

    bst = BinarySearchTree()

    start = time.time()
    for i in range(1, 10001):
        bst.insert(i)
    elapsed = time.time() - start

    print(f"  Time to insert 10,000 sequential numbers: {elapsed:.4f} seconds")
    print(f"  Tree height: {bst.height()}")
    print(f"  Min: {bst.find_min()}, Max: {bst.find_max()}")
    print()
    print("  PROBLEM: The tree becomes a straight line (like a linked list)!")
    print("  Height is 9999, which means search is O(n) instead of O(log n).")

    return bst.height()


def test_random_insertion():
    print("\n" + "=" * 60)
    print("RANDOM INSERTION TEST (10,000 random values)")
    print("=" * 60)

    numbers = list(range(1, 10001))
    random.shuffle(numbers)

    bst = BinarySearchTree()

    start = time.time()
    for num in numbers:
        bst.insert(num)
    elapsed = time.time() - start

    print(f"  Time to insert 10,000 random numbers: {elapsed:.4f} seconds")
    print(f"  Tree height: {bst.height()}")
    print(f"  Min: {bst.find_min()}, Max: {bst.find_max()}")
    print()
    print("  MUCH BETTER: Random insertion creates a balanced-ish tree.")
    print(f"  Height is ~{bst.height()}, close to ideal log2(10000) = ~13")

    return bst.height()


if __name__ == "__main__":
    seq_height = test_sequential_insertion()
    rand_height = test_random_insertion()

    print("\n" + "=" * 60)
    print("COMPARISON")
    print("=" * 60)
    print(f"  Sequential insertion height: {seq_height}")
    print(f"  Random insertion height:     {rand_height}")
    print(f"  Ideal height (log2 n):       ~13")
    print()
    print("EXPLANATION:")
    print("-" * 60)
    print("""
  When we insert numbers in order (1, 2, 3, ...), each new number
  is always greater than the previous one. So every node goes to
  the right side. The tree becomes a straight line - basically a
  linked list. This is called a 'degenerate' or 'skewed' tree.

  With random insertion, numbers go left and right more evenly,
  creating a more balanced tree. The height stays close to log2(n).

  This is why balanced BSTs (like AVL trees or Red-Black trees)
  exist - they automatically rebalance after every insertion to
  guarantee O(log n) height regardless of insertion order.
""")
