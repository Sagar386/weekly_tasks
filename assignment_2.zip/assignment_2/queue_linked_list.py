class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class QueueLinkedList:
    """Queue implementation using a linked list."""

    def __init__(self):
        self._front_node = None
        self._rear_node = None
        self._size = 0

    def enqueue(self, value):
        new_node = Node(value)

        if self._rear_node is None:
            self._front_node = new_node
            self._rear_node = new_node
        else:
            self._rear_node.next = new_node
            self._rear_node = new_node

        self._size += 1

    def dequeue(self):
        if self.is_empty():
            raise IndexError("Cannot dequeue from an empty queue")

        value = self._front_node.data
        self._front_node = self._front_node.next

        if self._front_node is None:
            self._rear_node = None

        self._size -= 1
        return value

    def front(self):
        if self.is_empty():
            raise IndexError("Queue is empty")
        return self._front_node.data

    def is_empty(self):
        return self._front_node is None

    def size(self):
        return self._size

    def __str__(self):
        items = []
        current = self._front_node
        while current is not None:
            items.append(str(current.data))
            current = current.next
        return "Queue (front -> rear): [" + ", ".join(items) + "]"
