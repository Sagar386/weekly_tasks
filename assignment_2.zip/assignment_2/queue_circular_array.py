class QueueCircularArray:
    """Queue implementation using a circular array."""

    def __init__(self, initial_capacity=8):
        self._data = [None] * initial_capacity
        self._front = 0
        self._rear = 0
        self._size = 0
        self._capacity = initial_capacity

    def enqueue(self, value):
        if self._size == self._capacity:
            self._resize(self._capacity * 2)

        self._data[self._rear] = value
        self._rear = (self._rear + 1) % self._capacity
        self._size += 1

    def dequeue(self):
        if self.is_empty():
            raise IndexError("Cannot dequeue from an empty queue")

        value = self._data[self._front]
        self._data[self._front] = None
        self._front = (self._front + 1) % self._capacity
        self._size -= 1
        return value

    def front(self):
        if self.is_empty():
            raise IndexError("Queue is empty")
        return self._data[self._front]

    def is_empty(self):
        return self._size == 0

    def size(self):
        return self._size

    def _resize(self, new_capacity):
        new_data = [None] * new_capacity
        for i in range(self._size):
            new_data[i] = self._data[(self._front + i) % self._capacity]
        self._data = new_data
        self._front = 0
        self._rear = self._size
        self._capacity = new_capacity

    def __str__(self):
        items = []
        for i in range(self._size):
            idx = (self._front + i) % self._capacity
            items.append(str(self._data[idx]))
        return "Queue (front -> rear): [" + ", ".join(items) + "]"
