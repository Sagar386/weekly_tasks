import unittest
from stack_array import StackArray
from stack_linked_list import StackLinkedList
from queue_circular_array import QueueCircularArray
from queue_linked_list import QueueLinkedList


class TestStackArray(unittest.TestCase):

    def test_push_and_pop(self):
        s = StackArray()
        s.push(1)
        s.push(2)
        s.push(3)
        self.assertEqual(s.pop(), 3)
        self.assertEqual(s.pop(), 2)
        self.assertEqual(s.pop(), 1)

    def test_peek(self):
        s = StackArray()
        s.push(10)
        s.push(20)
        self.assertEqual(s.peek(), 20)
        self.assertEqual(s.size(), 2)  # peek should not remove

    def test_is_empty(self):
        s = StackArray()
        self.assertTrue(s.is_empty())
        s.push(1)
        self.assertFalse(s.is_empty())

    def test_size(self):
        s = StackArray()
        self.assertEqual(s.size(), 0)
        s.push(1)
        s.push(2)
        self.assertEqual(s.size(), 2)

    def test_pop_empty_raises(self):
        s = StackArray()
        with self.assertRaises(IndexError):
            s.pop()

    def test_peek_empty_raises(self):
        s = StackArray()
        with self.assertRaises(IndexError):
            s.peek()


class TestStackLinkedList(unittest.TestCase):

    def test_push_and_pop(self):
        s = StackLinkedList()
        s.push(1)
        s.push(2)
        s.push(3)
        self.assertEqual(s.pop(), 3)
        self.assertEqual(s.pop(), 2)

    def test_peek(self):
        s = StackLinkedList()
        s.push(10)
        self.assertEqual(s.peek(), 10)
        self.assertEqual(s.size(), 1)

    def test_is_empty(self):
        s = StackLinkedList()
        self.assertTrue(s.is_empty())
        s.push(5)
        self.assertFalse(s.is_empty())

    def test_pop_empty_raises(self):
        s = StackLinkedList()
        with self.assertRaises(IndexError):
            s.pop()

    def test_lifo_order(self):
        s = StackLinkedList()
        for i in range(5):
            s.push(i)
        result = []
        while not s.is_empty():
            result.append(s.pop())
        self.assertEqual(result, [4, 3, 2, 1, 0])


class TestQueueCircularArray(unittest.TestCase):

    def test_enqueue_and_dequeue(self):
        q = QueueCircularArray()
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.dequeue(), 2)

    def test_front(self):
        q = QueueCircularArray()
        q.enqueue(10)
        q.enqueue(20)
        self.assertEqual(q.front(), 10)
        self.assertEqual(q.size(), 2)

    def test_is_empty(self):
        q = QueueCircularArray()
        self.assertTrue(q.is_empty())
        q.enqueue(1)
        self.assertFalse(q.is_empty())

    def test_dequeue_empty_raises(self):
        q = QueueCircularArray()
        with self.assertRaises(IndexError):
            q.dequeue()

    def test_wrap_around(self):
        q = QueueCircularArray(initial_capacity=4)
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        q.dequeue()  # remove 1
        q.dequeue()  # remove 2
        q.enqueue(4)
        q.enqueue(5)
        self.assertEqual(q.dequeue(), 3)
        self.assertEqual(q.dequeue(), 4)
        self.assertEqual(q.dequeue(), 5)

    def test_fifo_order(self):
        q = QueueCircularArray()
        for i in range(5):
            q.enqueue(i)
        result = []
        while not q.is_empty():
            result.append(q.dequeue())
        self.assertEqual(result, [0, 1, 2, 3, 4])

    def test_resize(self):
        q = QueueCircularArray(initial_capacity=2)
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)  # triggers resize
        self.assertEqual(q.size(), 3)
        self.assertEqual(q.dequeue(), 1)


class TestQueueLinkedList(unittest.TestCase):

    def test_enqueue_and_dequeue(self):
        q = QueueLinkedList()
        q.enqueue(1)
        q.enqueue(2)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.dequeue(), 2)

    def test_front(self):
        q = QueueLinkedList()
        q.enqueue(10)
        self.assertEqual(q.front(), 10)

    def test_is_empty(self):
        q = QueueLinkedList()
        self.assertTrue(q.is_empty())
        q.enqueue(1)
        self.assertFalse(q.is_empty())

    def test_dequeue_empty_raises(self):
        q = QueueLinkedList()
        with self.assertRaises(IndexError):
            q.dequeue()

    def test_size(self):
        q = QueueLinkedList()
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        self.assertEqual(q.size(), 3)
        q.dequeue()
        self.assertEqual(q.size(), 2)

    def test_fifo_order(self):
        q = QueueLinkedList()
        for i in range(5):
            q.enqueue(i)
        result = []
        while not q.is_empty():
            result.append(q.dequeue())
        self.assertEqual(result, [0, 1, 2, 3, 4])


if __name__ == "__main__":
    unittest.main()
