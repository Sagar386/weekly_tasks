class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class StackLinkedList:
    """Stack implementation using a linked list."""

    def __init__(self):
        self._top = None
        self._size = 0

    def push(self, value):
        new_node = Node(value)
        new_node.next = self._top
        self._top = new_node
        self._size += 1

    def pop(self):
        if self.is_empty():
            raise IndexError("Cannot pop from an empty stack")
        value = self._top.data
        self._top = self._top.next
        self._size -= 1
        return value

    def peek(self):
        if self.is_empty():
            raise IndexError("Cannot peek an empty stack")
        return self._top.data

    def is_empty(self):
        return self._top is None

    def size(self):
        return self._size

    def __str__(self):
        items = []
        current = self._top
        while current is not None:
            items.append(str(current.data))
            current = current.next
        return "Stack (top -> bottom): [" + ", ".join(items) + "]"
