import time
from stack_array import StackArray
from stack_linked_list import StackLinkedList
from queue_circular_array import QueueCircularArray
from queue_linked_list import QueueLinkedList


NUM_ELEMENTS = 100000


def test_stack_performance():
    print("=" * 60)
    print(f"STACK PERFORMANCE TEST ({NUM_ELEMENTS:,} elements)")
    print("=" * 60)

    # --- Stack using Array ---
    stack_arr = StackArray()

    start = time.time()
    for i in range(NUM_ELEMENTS):
        stack_arr.push(i)
    push_time_arr = time.time() - start

    start = time.time()
    for i in range(NUM_ELEMENTS):
        stack_arr.pop()
    pop_time_arr = time.time() - start

    print(f"\nStack (Array-based):")
    print(f"  Push {NUM_ELEMENTS:,} elements: {push_time_arr:.4f} seconds")
    print(f"  Pop  {NUM_ELEMENTS:,} elements: {pop_time_arr:.4f} seconds")
    print(f"  Total: {push_time_arr + pop_time_arr:.4f} seconds")

    # --- Stack using Linked List ---
    stack_ll = StackLinkedList()

    start = time.time()
    for i in range(NUM_ELEMENTS):
        stack_ll.push(i)
    push_time_ll = time.time() - start

    start = time.time()
    for i in range(NUM_ELEMENTS):
        stack_ll.pop()
    pop_time_ll = time.time() - start

    print(f"\nStack (Linked List-based):")
    print(f"  Push {NUM_ELEMENTS:,} elements: {push_time_ll:.4f} seconds")
    print(f"  Pop  {NUM_ELEMENTS:,} elements: {pop_time_ll:.4f} seconds")
    print(f"  Total: {push_time_ll + pop_time_ll:.4f} seconds")

    print(f"\nComparison:")
    if push_time_arr + pop_time_arr < push_time_ll + pop_time_ll:
        print(f"  Array-based stack is faster overall")
    else:
        print(f"  Linked list-based stack is faster overall")


def test_queue_performance():
    print("\n" + "=" * 60)
    print(f"QUEUE PERFORMANCE TEST ({NUM_ELEMENTS:,} elements)")
    print("=" * 60)

    # --- Queue using Circular Array ---
    queue_ca = QueueCircularArray()

    start = time.time()
    for i in range(NUM_ELEMENTS):
        queue_ca.enqueue(i)
    enq_time_ca = time.time() - start

    start = time.time()
    for i in range(NUM_ELEMENTS):
        queue_ca.dequeue()
    deq_time_ca = time.time() - start

    print(f"\nQueue (Circular Array):")
    print(f"  Enqueue {NUM_ELEMENTS:,} elements: {enq_time_ca:.4f} seconds")
    print(f"  Dequeue {NUM_ELEMENTS:,} elements: {deq_time_ca:.4f} seconds")
    print(f"  Total: {enq_time_ca + deq_time_ca:.4f} seconds")

    # --- Queue using Linked List ---
    queue_ll = QueueLinkedList()

    start = time.time()
    for i in range(NUM_ELEMENTS):
        queue_ll.enqueue(i)
    enq_time_ll = time.time() - start

    start = time.time()
    for i in range(NUM_ELEMENTS):
        queue_ll.dequeue()
    deq_time_ll = time.time() - start

    print(f"\nQueue (Linked List):")
    print(f"  Enqueue {NUM_ELEMENTS:,} elements: {enq_time_ll:.4f} seconds")
    print(f"  Dequeue {NUM_ELEMENTS:,} elements: {deq_time_ll:.4f} seconds")
    print(f"  Total: {enq_time_ll + deq_time_ll:.4f} seconds")

    print(f"\nComparison:")
    if enq_time_ca + deq_time_ca < enq_time_ll + deq_time_ll:
        print(f"  Circular array queue is faster overall")
    else:
        print(f"  Linked list queue is faster overall")


if __name__ == "__main__":
    test_stack_performance()
    test_queue_performance()

    print("\n" + "=" * 60)
    print("WHY CIRCULAR ARRAY AVOIDS SHIFTING COST")
    print("=" * 60)
    print("""
In a normal array-based queue, every dequeue operation would require
shifting all remaining elements one position to the left. That makes
dequeue O(n) - very slow for large queues.

A circular array solves this by using two pointers (front and rear)
that wrap around the array. When we dequeue, we just move the front
pointer forward. No shifting is needed, so dequeue becomes O(1).

The array is treated as if the end connects back to the beginning,
like a circle. When rear reaches the end of the array, it wraps
around to index 0 (if there's space).
""")
