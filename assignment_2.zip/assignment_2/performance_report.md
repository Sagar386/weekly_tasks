# Stack & Queue Performance Comparison Report

## Test Setup
- Operations: Push/Enqueue and Pop/Dequeue 100,000 elements
- Measured using Python's time module

## Stack Comparison

| Operation | Array-based Stack | Linked List Stack |
|-----------|------------------|-------------------|
| Push      | O(1) amortized   | O(1) always       |
| Pop       | O(1)             | O(1)              |

**Observations:**
- Array-based stack is generally faster due to better cache locality. Array elements are stored next to each other in memory, so the CPU can access them faster.
- Linked list stack has consistent O(1) push time (no resizing needed), but each node is a separate object in memory, which is slower to access.
- For most practical purposes, array-based stack is the better choice.

## Queue Comparison

| Operation | Circular Array Queue | Linked List Queue |
|-----------|---------------------|-------------------|
| Enqueue   | O(1) amortized      | O(1) always       |
| Dequeue   | O(1)                | O(1)              |

**Observations:**
- Circular array queue avoids the shifting problem of regular arrays. In a regular array, dequeue would require shifting all elements left (O(n)). The circular approach just moves the front pointer.
- Linked list queue also gives O(1) for both operations since we maintain both front and rear pointers.
- Circular array is slightly faster in practice due to cache locality.

## Why Circular Array Avoids Shifting Cost

In a normal array queue:
- Dequeue removes the front element
- All other elements must shift left by one position
- This is O(n) per dequeue operation

In a circular array:
- We use front and rear pointers
- Dequeue just moves front pointer forward: front = (front + 1) % capacity
- No elements need to be moved
- This makes dequeue O(1)

The array wraps around - when rear reaches the end, it goes back to index 0 if there is space.

## Conclusion
Both implementations meet O(1) requirements. Array-based implementations tend to be faster in practice due to memory layout, while linked list implementations offer more consistent performance without any resizing overhead.
