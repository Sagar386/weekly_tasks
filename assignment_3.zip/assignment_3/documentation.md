# Hash Map - Documentation

## What is a Hash Map?

A hash map (also called hash table) is a data structure that stores key-value pairs. It allows you to quickly look up a value if you know the key. Think of it like a dictionary - you look up a word (key) to find its meaning (value).

## How Does Hashing Work?

When you insert a key-value pair:
1. The key is passed through a **hash function**
2. The hash function converts the key into a number (the index)
3. The value is stored at that index in an internal array

For example:
- Key "name" -> hash function -> index 3 -> stored at position 3
- Key "age" -> hash function -> index 7 -> stored at position 7

## What is a Collision?

A collision happens when two different keys produce the same index after hashing. For example:
- Key "abc" -> hash function -> index 3
- Key "xyz" -> hash function -> index 3 (same index!)

Since both keys want to go to the same position, we need a way to handle this.

## Collision Handling: Separate Chaining

Our implementation uses **separate chaining** to handle collisions:
- Each position in the array holds a linked list (a chain)
- When two keys hash to the same index, both are stored in that linked list
- To find a value, we go to the index and then search through the chain

Example:
```
Index 0: None
Index 1: None
Index 2: ("abc", 10) -> ("xyz", 20) -> None
Index 3: ("name", "Alice") -> None
Index 4: None
```

## What is Load Factor?

Load factor = number of items / capacity of the array

```
load_factor = size / capacity
```

For example, if we have 6 items in an array of capacity 8:
- Load factor = 6/8 = 0.75

A higher load factor means more collisions are likely, which slows down operations.

## Why Resize at 0.75?

When the load factor exceeds 0.75, we double the array size and rehash all items. This keeps the chains short and operations fast. The value 0.75 is a good balance between:
- Memory usage (don't want to waste too much space)
- Performance (don't want chains to get too long)

## Time Complexity Analysis

| Operation  | Average Case | Worst Case |
|------------|-------------|------------|
| put()      | O(1)        | O(n)       |
| get()      | O(1)        | O(n)       |
| delete()   | O(1)        | O(n)       |
| contains() | O(1)        | O(n)       |

- **Average case O(1)**: With a good hash function and low load factor, we jump directly to the right index. The chain at that index is very short (usually 1 item).

- **Worst case O(n)**: If all keys hash to the same index (very unlikely with a good hash function), we would have one long chain and would need to search through all n items.

## Our Hash Function

For integer keys:
- We use `abs(key) % capacity` to get the index
- `abs()` handles negative numbers

For string keys:
- We calculate: hash = (hash * 31 + character_code) for each character
- The multiplier 31 helps spread values more evenly
- Then we take `% capacity` to get the index

## Design Choices

1. **Separate chaining over open addressing**: Easier to implement and understand. Deletion is straightforward (just remove from linked list).

2. **Initial capacity of 8**: Small enough to not waste memory for small maps, large enough to avoid immediate resizing.

3. **Load factor threshold of 0.75**: Industry standard (used by Java's HashMap too). Good balance of speed and memory.

4. **Doubling on resize**: Amortized O(1) insertion. Each resize is O(n), but it happens rarely enough that the average cost stays O(1).
