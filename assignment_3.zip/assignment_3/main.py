from hash_map import HashMap


def main():
    print("=" * 50)
    print("CUSTOM HASH MAP DEMO")
    print("=" * 50)

    hm = HashMap()

    # inserting key-value pairs
    print("\nInserting items:")
    hm.put("name", "Alice")
    hm.put("age", 25)
    hm.put("city", "Mumbai")
    hm.put("role", "Developer")
    print(f"  HashMap: {hm}")
    print(f"  Size: {hm.size()}")
    print(f"  Load factor: {hm.load_factor():.2f}")

    # getting values
    print("\nGetting values:")
    print(f"  name -> {hm.get('name')}")
    print(f"  age  -> {hm.get('age')}")

    # checking if key exists
    print("\nChecking keys:")
    print(f"  Contains 'city': {hm.contains('city')}")
    print(f"  Contains 'email': {hm.contains('email')}")

    # updating a value
    print("\nUpdating 'age' to 26:")
    hm.put("age", 26)
    print(f"  age -> {hm.get('age')}")
    print(f"  Size (should still be 4): {hm.size()}")

    # deleting
    print("\nDeleting 'city':")
    hm.delete("city")
    print(f"  Contains 'city': {hm.contains('city')}")
    print(f"  Size: {hm.size()}")

    # working with integer keys
    print("\n--- Integer keys ---")
    hm2 = HashMap()
    hm2.put(1, "one")
    hm2.put(2, "two")
    hm2.put(-3, "negative three")
    print(f"  HashMap: {hm2}")
    print(f"  Key -3 -> {hm2.get(-3)}")

    # showing all keys and values
    print(f"\nAll keys: {hm.keys()}")
    print(f"All values: {hm.values()}")

    # demonstrating collision handling with small capacity
    print("\n--- Collision demo (capacity=2) ---")
    small_hm = HashMap(initial_capacity=2)
    small_hm.put("a", 1)
    small_hm.put("b", 2)
    small_hm.put("c", 3)
    print(f"  All items accessible: a={small_hm.get('a')}, b={small_hm.get('b')}, c={small_hm.get('c')}")
    print(f"  Size: {small_hm.size()}")


if __name__ == "__main__":
    main()
