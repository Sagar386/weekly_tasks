class HashNode:
    """A node in the linked list chain for handling collisions."""

    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.next = None


class HashMap:
    """Custom hash map using separate chaining for collision handling."""

    def __init__(self, initial_capacity=8):
        self._capacity = initial_capacity
        self._size = 0
        self._buckets = [None] * self._capacity
        self._load_factor_threshold = 0.75

    def _hash(self, key):
        """Generate a hash index for the given key."""
        if isinstance(key, int):
            return abs(key) % self._capacity
        elif isinstance(key, str):
            # simple string hash - sum of character codes
            hash_value = 0
            for char in key:
                hash_value = hash_value * 31 + ord(char)
            return abs(hash_value) % self._capacity
        else:
            return hash(key) % self._capacity

    def put(self, key, value):
        """Insert or update a key-value pair."""
        # check if we need to resize
        if (self._size + 1) / self._capacity > self._load_factor_threshold:
            self._resize()

        index = self._hash(key)
        current = self._buckets[index]

        # check if key already exists - update it
        while current is not None:
            if current.key == key:
                current.value = value
                return
            current = current.next

        # key does not exist - add new node at the front of the chain
        new_node = HashNode(key, value)
        new_node.next = self._buckets[index]
        self._buckets[index] = new_node
        self._size += 1

    def get(self, key):
        """Get value by key. Raises KeyError if not found."""
        index = self._hash(key)
        current = self._buckets[index]

        while current is not None:
            if current.key == key:
                return current.value
            current = current.next

        raise KeyError(f"Key '{key}' not found")

    def delete(self, key):
        """Delete a key-value pair. Raises KeyError if not found."""
        index = self._hash(key)
        current = self._buckets[index]
        prev = None

        while current is not None:
            if current.key == key:
                if prev is None:
                    self._buckets[index] = current.next
                else:
                    prev.next = current.next
                self._size -= 1
                return current.value
            prev = current
            current = current.next

        raise KeyError(f"Key '{key}' not found")

    def contains(self, key):
        """Check if a key exists in the map."""
        index = self._hash(key)
        current = self._buckets[index]

        while current is not None:
            if current.key == key:
                return True
            current = current.next

        return False

    def size(self):
        return self._size

    def load_factor(self):
        return self._size / self._capacity

    def _resize(self):
        """Double the capacity and rehash all existing entries."""
        old_buckets = self._buckets
        self._capacity = self._capacity * 2
        self._buckets = [None] * self._capacity
        self._size = 0

        for bucket in old_buckets:
            current = bucket
            while current is not None:
                self.put(current.key, current.value)
                current = current.next

    def keys(self):
        """Return all keys in the map."""
        result = []
        for bucket in self._buckets:
            current = bucket
            while current is not None:
                result.append(current.key)
                current = current.next
        return result

    def values(self):
        """Return all values in the map."""
        result = []
        for bucket in self._buckets:
            current = bucket
            while current is not None:
                result.append(current.value)
                current = current.next
        return result

    def __str__(self):
        pairs = []
        for bucket in self._buckets:
            current = bucket
            while current is not None:
                pairs.append(f"{current.key}: {current.value}")
                current = current.next
        return "{" + ", ".join(pairs) + "}"
