import unittest
from hash_map import HashMap


class TestHashMap(unittest.TestCase):

    def test_put_and_get(self):
        hm = HashMap()
        hm.put("name", "Alice")
        self.assertEqual(hm.get("name"), "Alice")

    def test_put_multiple(self):
        hm = HashMap()
        hm.put("a", 1)
        hm.put("b", 2)
        hm.put("c", 3)
        self.assertEqual(hm.get("a"), 1)
        self.assertEqual(hm.get("b"), 2)
        self.assertEqual(hm.get("c"), 3)

    def test_duplicate_key_overwrite(self):
        hm = HashMap()
        hm.put("key", "old_value")
        hm.put("key", "new_value")
        self.assertEqual(hm.get("key"), "new_value")
        self.assertEqual(hm.size(), 1)

    def test_get_key_not_found(self):
        hm = HashMap()
        hm.put("a", 1)
        with self.assertRaises(KeyError):
            hm.get("z")

    def test_delete(self):
        hm = HashMap()
        hm.put("x", 100)
        hm.delete("x")
        self.assertFalse(hm.contains("x"))
        self.assertEqual(hm.size(), 0)

    def test_delete_key_not_found(self):
        hm = HashMap()
        with self.assertRaises(KeyError):
            hm.delete("missing")

    def test_contains_true(self):
        hm = HashMap()
        hm.put("hello", "world")
        self.assertTrue(hm.contains("hello"))

    def test_contains_false(self):
        hm = HashMap()
        self.assertFalse(hm.contains("nope"))

    def test_size(self):
        hm = HashMap()
        self.assertEqual(hm.size(), 0)
        hm.put("a", 1)
        hm.put("b", 2)
        self.assertEqual(hm.size(), 2)
        hm.delete("a")
        self.assertEqual(hm.size(), 1)

    def test_integer_keys(self):
        hm = HashMap()
        hm.put(1, "one")
        hm.put(2, "two")
        self.assertEqual(hm.get(1), "one")
        self.assertEqual(hm.get(2), "two")

    def test_negative_keys(self):
        hm = HashMap()
        hm.put(-5, "negative five")
        hm.put(-10, "negative ten")
        self.assertEqual(hm.get(-5), "negative five")
        self.assertEqual(hm.get(-10), "negative ten")

    def test_string_keys(self):
        hm = HashMap()
        hm.put("apple", 1)
        hm.put("banana", 2)
        hm.put("cherry", 3)
        self.assertEqual(hm.get("apple"), 1)
        self.assertEqual(hm.get("banana"), 2)

    def test_collision_handling(self):
        # use a small capacity to force collisions
        hm = HashMap(initial_capacity=2)
        hm.put("a", 1)
        hm.put("b", 2)
        hm.put("c", 3)
        hm.put("d", 4)
        self.assertEqual(hm.get("a"), 1)
        self.assertEqual(hm.get("b"), 2)
        self.assertEqual(hm.get("c"), 3)
        self.assertEqual(hm.get("d"), 4)

    def test_resize_triggered(self):
        hm = HashMap(initial_capacity=4)
        # adding 4 items to capacity 4 should trigger resize (load > 0.75)
        hm.put("a", 1)
        hm.put("b", 2)
        hm.put("c", 3)
        hm.put("d", 4)
        # all items should still be accessible after resize
        self.assertEqual(hm.get("a"), 1)
        self.assertEqual(hm.get("d"), 4)

    def test_load_factor(self):
        hm = HashMap(initial_capacity=10)
        hm.put("a", 1)
        hm.put("b", 2)
        self.assertAlmostEqual(hm.load_factor(), 0.2)

    def test_keys_method(self):
        hm = HashMap()
        hm.put("x", 1)
        hm.put("y", 2)
        keys = hm.keys()
        self.assertIn("x", keys)
        self.assertIn("y", keys)
        self.assertEqual(len(keys), 2)

    def test_values_method(self):
        hm = HashMap()
        hm.put("x", 10)
        hm.put("y", 20)
        values = hm.values()
        self.assertIn(10, values)
        self.assertIn(20, values)

    def test_delete_and_reinsert(self):
        hm = HashMap()
        hm.put("key", "first")
        hm.delete("key")
        hm.put("key", "second")
        self.assertEqual(hm.get("key"), "second")

    def test_many_items(self):
        hm = HashMap()
        for i in range(100):
            hm.put(f"key_{i}", i)
        self.assertEqual(hm.size(), 100)
        for i in range(100):
            self.assertEqual(hm.get(f"key_{i}"), i)

    def test_mixed_key_types(self):
        hm = HashMap()
        hm.put(1, "int")
        hm.put("one", "str")
        self.assertEqual(hm.get(1), "int")
        self.assertEqual(hm.get("one"), "str")

    def test_empty_string_key(self):
        hm = HashMap()
        hm.put("", "empty")
        self.assertEqual(hm.get(""), "empty")


if __name__ == "__main__":
    unittest.main()
