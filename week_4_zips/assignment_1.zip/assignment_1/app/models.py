from pydantic import BaseModel


class ContactCreate(BaseModel):
    """Schema for creating or updating a contact."""
    name: str
    email: str
    phone: str


class ContactResponse(ContactCreate):
    """Schema for returning a contact (includes the auto-generated id)."""
    id: int
