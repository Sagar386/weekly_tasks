from fastapi import APIRouter, HTTPException
from app.models import ContactCreate, ContactResponse

router = APIRouter(prefix="/contacts", tags=["Contacts"])

# in-memory storage
contacts_db = {}
next_id = 1


@router.get("/", response_model=list[ContactResponse])
def get_contacts():
    """Return all contacts."""
    return list(contacts_db.values())


@router.get("/{contact_id}", response_model=ContactResponse)
def get_contact(contact_id: int):
    """Return a single contact by id."""
    if contact_id not in contacts_db:
        raise HTTPException(status_code=404, detail=f"Contact with id {contact_id} not found")
    return contacts_db[contact_id]


@router.post("/", response_model=ContactResponse, status_code=201)
def create_contact(contact: ContactCreate):
    """Create a new contact and return it with an assigned id."""
    global next_id
    new_contact = {"id": next_id, **contact.model_dump()}
    contacts_db[next_id] = new_contact
    next_id += 1
    return new_contact


@router.put("/{contact_id}", response_model=ContactResponse)
def update_contact(contact_id: int, contact: ContactCreate):
    """Update an existing contact."""
    if contact_id not in contacts_db:
        raise HTTPException(status_code=404, detail=f"Contact with id {contact_id} not found")
    updated = {"id": contact_id, **contact.model_dump()}
    contacts_db[contact_id] = updated
    return updated


@router.delete("/{contact_id}")
def delete_contact(contact_id: int):
    """Delete a contact by id."""
    if contact_id not in contacts_db:
        raise HTTPException(status_code=404, detail=f"Contact with id {contact_id} not found")
    del contacts_db[contact_id]
    return {"message": f"Contact {contact_id} deleted"}
