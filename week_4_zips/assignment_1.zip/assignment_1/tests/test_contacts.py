import unittest
from fastapi.testclient import TestClient
from app.main import app
import app.routes as routes_module


class TestContacts(unittest.TestCase):

    def setUp(self):
        """Reset the database before each test."""
        routes_module.contacts_db.clear()
        routes_module.next_id = 1
        self.client = TestClient(app)

    # -- CREATE --

    def test_create_contact(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice Smith",
            "email": "alice@example.com",
            "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertEqual(data["name"], "Alice Smith")
        self.assertEqual(data["email"], "alice@example.com")

    def test_create_contact_returns_id(self):
        response = self.client.post("/contacts/", json={
            "name": "Bob", "email": "bob@test.com", "phone": "9876543210"
        })
        self.assertEqual(response.json()["id"], 1)

    def test_create_multiple_contacts_increments_id(self):
        self.client.post("/contacts/", json={
            "name": "A", "email": "a@a.com", "phone": "1111111111"
        })
        response = self.client.post("/contacts/", json={
            "name": "B", "email": "b@b.com", "phone": "2222222222"
        })
        self.assertEqual(response.json()["id"], 2)

    # -- READ --

    def test_get_all_contacts_empty(self):
        response = self.client.get("/contacts/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), [])

    def test_get_all_contacts(self):
        self.client.post("/contacts/", json={
            "name": "A", "email": "a@a.com", "phone": "1111111111"
        })
        self.client.post("/contacts/", json={
            "name": "B", "email": "b@b.com", "phone": "2222222222"
        })
        response = self.client.get("/contacts/")
        self.assertEqual(len(response.json()), 2)

    def test_get_contact_by_id(self):
        self.client.post("/contacts/", json={
            "name": "Charlie", "email": "charlie@mail.com", "phone": "5555555555"
        })
        response = self.client.get("/contacts/1")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["name"], "Charlie")

    def test_get_contact_not_found(self):
        response = self.client.get("/contacts/999")
        self.assertEqual(response.status_code, 404)

    # -- UPDATE --

    def test_update_contact(self):
        self.client.post("/contacts/", json={
            "name": "Old Name", "email": "old@mail.com", "phone": "1111111111"
        })
        response = self.client.put("/contacts/1", json={
            "name": "New Name", "email": "new@mail.com", "phone": "2222222222"
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["name"], "New Name")
        self.assertEqual(response.json()["email"], "new@mail.com")

    def test_update_contact_not_found(self):
        response = self.client.put("/contacts/999", json={
            "name": "X", "email": "x@x.com", "phone": "0000000000"
        })
        self.assertEqual(response.status_code, 404)

    # -- DELETE --

    def test_delete_contact(self):
        self.client.post("/contacts/", json={
            "name": "ToDelete", "email": "del@mail.com", "phone": "1111111111"
        })
        response = self.client.delete("/contacts/1")
        self.assertEqual(response.status_code, 200)
        # verify it's gone
        get_response = self.client.get("/contacts/1")
        self.assertEqual(get_response.status_code, 404)

    def test_delete_contact_not_found(self):
        response = self.client.delete("/contacts/999")
        self.assertEqual(response.status_code, 404)

    # -- FULL CYCLE --

    def test_full_crud_cycle(self):
        # create
        create = self.client.post("/contacts/", json={
            "name": "Full Cycle", "email": "cycle@test.com", "phone": "9999999999"
        })
        contact_id = create.json()["id"]

        # read
        read = self.client.get(f"/contacts/{contact_id}")
        self.assertEqual(read.json()["name"], "Full Cycle")

        # update
        update = self.client.put(f"/contacts/{contact_id}", json={
            "name": "Updated Cycle", "email": "updated@test.com", "phone": "8888888888"
        })
        self.assertEqual(update.json()["name"], "Updated Cycle")

        # delete
        self.client.delete(f"/contacts/{contact_id}")

        # verify gone
        gone = self.client.get(f"/contacts/{contact_id}")
        self.assertEqual(gone.status_code, 404)


if __name__ == "__main__":
    unittest.main()
