import re
from pydantic import BaseModel, ConfigDict, field_validator


class ContactCreate(BaseModel):
    """Schema for creating or updating a contact."""
    name: str
    email: str
    phone: str

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "name": "John Doe",
                "email": "john.doe@example.com",
                "phone": "1234567890"
            }
        }
    )

    @field_validator("name")
    @classmethod
    def name_must_not_be_empty(cls, v):
        if not v or not v.strip():
            raise ValueError("Name cannot be empty")
        return v.strip()

    @field_validator("email")
    @classmethod
    def email_must_be_valid(cls, v):
        pattern = r'^[^@]+@[^@]+\.[^@]+$'
        if not re.match(pattern, v):
            raise ValueError("Invalid email format. Must contain @ and a domain (e.g. user@example.com)")
        return v.lower().strip()

    @field_validator("phone")
    @classmethod
    def phone_must_be_valid(cls, v):
        digits = v.replace("+", "").replace("-", "").replace(" ", "").replace("(", "").replace(")", "")
        if not digits.isdigit():
            raise ValueError("Phone must contain only digits (and optionally +, -, spaces)")
        if len(digits) < 10:
            raise ValueError("Phone number must be at least 10 digits")
        return v.strip()


class ContactResponse(ContactCreate):
    """Schema for returning a contact (includes the auto-generated id)."""
    id: int

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "id": 1,
                "name": "John Doe",
                "email": "john.doe@example.com",
                "phone": "1234567890"
            }
        }
    )
