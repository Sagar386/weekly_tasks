from fastapi import APIRouter
from app.models import ContactCreate, ContactResponse
from app.exceptions import ResourceNotFoundError

router = APIRouter(prefix="/contacts", tags=["Contacts"])

# in-memory storage
contacts_db = {}
next_id = 1


@router.get("/", response_model=list[ContactResponse],
            summary="List all contacts",
            description="Returns a list of all contacts in the system.")
def get_contacts():
    return list(contacts_db.values())


@router.get("/{contact_id}", response_model=ContactResponse,
            summary="Get a contact by ID",
            responses={404: {"description": "Contact not found"}})
def get_contact(contact_id: int):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    return contacts_db[contact_id]


@router.post("/", response_model=ContactResponse, status_code=201,
             summary="Create a new contact",
             responses={400: {"description": "Invalid input data"}})
def create_contact(contact: ContactCreate):
    global next_id
    new_contact = {"id": next_id, **contact.model_dump()}
    contacts_db[next_id] = new_contact
    next_id += 1
    return new_contact


@router.put("/{contact_id}", response_model=ContactResponse,
            summary="Update a contact",
            responses={404: {"description": "Contact not found"},
                       400: {"description": "Invalid input data"}})
def update_contact(contact_id: int, contact: ContactCreate):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    updated = {"id": contact_id, **contact.model_dump()}
    contacts_db[contact_id] = updated
    return updated


@router.delete("/{contact_id}",
               summary="Delete a contact",
               responses={404: {"description": "Contact not found"}})
def delete_contact(contact_id: int):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    del contacts_db[contact_id]
    return {"message": f"Contact {contact_id} deleted"}
