import math
from typing import Optional
from fastapi import APIRouter, Query
from app.models import ContactCreate, ContactResponse, PaginatedResponse
from app.exceptions import ResourceNotFoundError

router = APIRouter(prefix="/contacts", tags=["Contacts"])

# in-memory storage
contacts_db = {}
next_id = 1


@router.get("/", response_model=PaginatedResponse,
            summary="List contacts with pagination, filtering and sorting")
def get_contacts(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(10, ge=1, le=100, description="Items per page"),
    name: Optional[str] = Query(None, description="Filter by name (case-insensitive)"),
    email: Optional[str] = Query(None, description="Filter by email (case-insensitive)"),
    sort_by: Optional[str] = Query(None, description="Sort by field: name, email, phone, id"),
    order: str = Query("asc", description="Sort order: asc or desc"),
):
    results = list(contacts_db.values())

    # filtering
    if name:
        results = [c for c in results if name.lower() in c["name"].lower()]
    if email:
        results = [c for c in results if email.lower() in c["email"].lower()]

    # sorting
    if sort_by and sort_by in ("name", "email", "phone", "id"):
        results.sort(key=lambda c: c[sort_by], reverse=(order == "desc"))

    # pagination
    total = len(results)
    pages = math.ceil(total / limit) if total > 0 else 1
    start = (page - 1) * limit
    end = start + limit
    page_results = results[start:end]

    return {
        "contacts": page_results,
        "total": total,
        "page": page,
        "limit": limit,
        "pages": pages,
    }


@router.get("/{contact_id}", response_model=ContactResponse,
            summary="Get a contact by ID",
            responses={404: {"description": "Contact not found"}})
def get_contact(contact_id: int):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    return contacts_db[contact_id]


@router.post("/", response_model=ContactResponse, status_code=201,
             summary="Create a new contact",
             responses={400: {"description": "Invalid input data"}})
def create_contact(contact: ContactCreate):
    global next_id
    new_contact = {"id": next_id, **contact.model_dump()}
    contacts_db[next_id] = new_contact
    next_id += 1
    return new_contact


@router.put("/{contact_id}", response_model=ContactResponse,
            summary="Update a contact",
            responses={404: {"description": "Contact not found"},
                       400: {"description": "Invalid input data"}})
def update_contact(contact_id: int, contact: ContactCreate):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    updated = {"id": contact_id, **contact.model_dump()}
    contacts_db[contact_id] = updated
    return updated


@router.delete("/{contact_id}",
               summary="Delete a contact",
               responses={404: {"description": "Contact not found"}})
def delete_contact(contact_id: int):
    if contact_id not in contacts_db:
        raise ResourceNotFoundError("Contact", contact_id)
    del contacts_db[contact_id]
    return {"message": f"Contact {contact_id} deleted"}
