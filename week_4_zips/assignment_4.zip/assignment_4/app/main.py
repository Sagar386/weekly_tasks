from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from app.routes import router
from app.exceptions import ResourceNotFoundError, ValidationError

app = FastAPI(
    title="Contact Manager API",
    description="A RESTful API for managing contacts. Supports CRUD operations with validation.",
    version="1.0.0",
)
app.include_router(router)


@app.exception_handler(ResourceNotFoundError)
async def not_found_handler(request: Request, exc: ResourceNotFoundError):
    return JSONResponse(status_code=404, content={"detail": str(exc)})


@app.exception_handler(ValidationError)
async def validation_error_handler(request: Request, exc: ValidationError):
    return JSONResponse(status_code=400, content={"detail": exc.message})


@app.exception_handler(RequestValidationError)
async def request_validation_handler(request: Request, exc: RequestValidationError):
    """Convert FastAPI's default 422 to a cleaner 400 response."""
    errors = exc.errors()
    messages = []
    for err in errors:
        field = err.get("loc", ["", ""])[-1]
        msg = err.get("msg", "Invalid value")
        messages.append(f"{field}: {msg}")
    return JSONResponse(status_code=400, content={"detail": "; ".join(messages)})


@app.exception_handler(Exception)
async def general_error_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
