import unittest
from fastapi.testclient import TestClient
from app.main import app
import app.routes as routes_module


class TestValidationAndErrors(unittest.TestCase):

    def setUp(self):
        routes_module.contacts_db.clear()
        routes_module.next_id = 1
        self.client = TestClient(app)

    # -- Missing fields --

    def test_create_missing_name(self):
        response = self.client.post("/contacts/", json={
            "email": "a@a.com", "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 400)

    def test_create_missing_email(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 400)

    def test_create_missing_phone(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "email": "alice@example.com"
        })
        self.assertEqual(response.status_code, 400)

    # -- Invalid email --

    def test_create_invalid_email_no_at(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "email": "aliceexample.com", "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 400)

    def test_create_invalid_email_no_dot(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "email": "alice@examplecom", "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 400)

    # -- Invalid phone --

    def test_create_invalid_phone_letters(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "email": "alice@example.com", "phone": "abcdefghij"
        })
        self.assertEqual(response.status_code, 400)

    def test_create_invalid_phone_too_short(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice", "email": "alice@example.com", "phone": "123"
        })
        self.assertEqual(response.status_code, 400)

    # -- Empty name --

    def test_create_empty_name(self):
        response = self.client.post("/contacts/", json={
            "name": "   ", "email": "alice@example.com", "phone": "1234567890"
        })
        self.assertEqual(response.status_code, 400)

    # -- 404 errors --

    def test_get_nonexistent_returns_404(self):
        response = self.client.get("/contacts/999")
        self.assertEqual(response.status_code, 404)
        self.assertIn("detail", response.json())

    def test_update_nonexistent_returns_404(self):
        response = self.client.put("/contacts/999", json={
            "name": "X", "email": "x@x.com", "phone": "0000000000"
        })
        self.assertEqual(response.status_code, 404)

    def test_delete_nonexistent_returns_404(self):
        response = self.client.delete("/contacts/999")
        self.assertEqual(response.status_code, 404)

    # -- Error response format --

    def test_error_response_has_detail_field(self):
        response = self.client.get("/contacts/999")
        data = response.json()
        self.assertIn("detail", data)
        self.assertIsInstance(data["detail"], str)

    # -- Valid data still works --

    def test_valid_data_passes(self):
        response = self.client.post("/contacts/", json={
            "name": "Alice Smith",
            "email": "alice@example.com",
            "phone": "+1-234-567-8901"
        })
        self.assertEqual(response.status_code, 201)


if __name__ == "__main__":
    unittest.main()
