import unittest
from fastapi.testclient import TestClient
from app.main import app
import app.routes as routes_module


class TestPaginationFilterSort(unittest.TestCase):

    def setUp(self):
        routes_module.contacts_db.clear()
        routes_module.next_id = 1
        self.client = TestClient(app)
        # seed some contacts for testing
        self.contacts = [
            {"name": "Alice Smith", "email": "alice@gmail.com", "phone": "1111111111"},
            {"name": "Bob Johnson", "email": "bob@yahoo.com", "phone": "2222222222"},
            {"name": "Charlie Brown", "email": "charlie@gmail.com", "phone": "3333333333"},
            {"name": "Diana Prince", "email": "diana@outlook.com", "phone": "4444444444"},
            {"name": "Eve Adams", "email": "eve@gmail.com", "phone": "5555555555"},
        ]
        for c in self.contacts:
            self.client.post("/contacts/", json=c)

    # -- Pagination --

    def test_default_pagination(self):
        response = self.client.get("/contacts/")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 5)
        self.assertEqual(data["total"], 5)
        self.assertEqual(data["page"], 1)

    def test_custom_page_size(self):
        response = self.client.get("/contacts/?limit=2")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 2)
        self.assertEqual(data["pages"], 3)  # 5 items / 2 per page = 3 pages

    def test_second_page(self):
        response = self.client.get("/contacts/?limit=2&page=2")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 2)
        self.assertEqual(data["page"], 2)

    def test_last_page_partial(self):
        response = self.client.get("/contacts/?limit=3&page=2")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 2)  # only 2 left on page 2

    def test_page_beyond_total(self):
        response = self.client.get("/contacts/?page=100")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 0)

    def test_pagination_metadata(self):
        response = self.client.get("/contacts/?limit=2")
        data = response.json()
        self.assertIn("total", data)
        self.assertIn("page", data)
        self.assertIn("limit", data)
        self.assertIn("pages", data)

    # -- Filtering --

    def test_filter_by_name(self):
        response = self.client.get("/contacts/?name=Alice")
        data = response.json()
        self.assertEqual(data["total"], 1)
        self.assertEqual(data["contacts"][0]["name"], "Alice Smith")

    def test_filter_by_email_domain(self):
        response = self.client.get("/contacts/?email=gmail")
        data = response.json()
        self.assertEqual(data["total"], 3)  # Alice, Charlie, Eve

    def test_filter_case_insensitive(self):
        response = self.client.get("/contacts/?name=alice")
        data = response.json()
        self.assertEqual(data["total"], 1)

    # -- Sorting --

    def test_sort_by_name_asc(self):
        response = self.client.get("/contacts/?sort_by=name&order=asc")
        names = [c["name"] for c in response.json()["contacts"]]
        self.assertEqual(names, sorted(names))

    def test_sort_by_name_desc(self):
        response = self.client.get("/contacts/?sort_by=name&order=desc")
        names = [c["name"] for c in response.json()["contacts"]]
        self.assertEqual(names, sorted(names, reverse=True))

    def test_sort_by_id(self):
        response = self.client.get("/contacts/?sort_by=id&order=asc")
        ids = [c["id"] for c in response.json()["contacts"]]
        self.assertEqual(ids, sorted(ids))

    # -- Combined --

    def test_filter_and_sort_combined(self):
        response = self.client.get("/contacts/?email=gmail&sort_by=name&order=desc")
        data = response.json()
        self.assertEqual(data["total"], 3)
        names = [c["name"] for c in data["contacts"]]
        self.assertEqual(names, sorted(names, reverse=True))

    def test_filter_and_paginate(self):
        response = self.client.get("/contacts/?email=gmail&limit=2&page=1")
        data = response.json()
        self.assertEqual(len(data["contacts"]), 2)
        self.assertEqual(data["total"], 3)


if __name__ == "__main__":
    unittest.main()
