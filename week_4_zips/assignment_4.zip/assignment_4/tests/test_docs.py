import unittest
from fastapi.testclient import TestClient
from app.main import app


class TestDocumentation(unittest.TestCase):

    def setUp(self):
        self.client = TestClient(app)

    def test_swagger_ui_accessible(self):
        response = self.client.get("/docs")
        self.assertEqual(response.status_code, 200)

    def test_redoc_accessible(self):
        response = self.client.get("/redoc")
        self.assertEqual(response.status_code, 200)

    def test_openapi_json_accessible(self):
        response = self.client.get("/openapi.json")
        self.assertEqual(response.status_code, 200)

    def test_openapi_has_contact_paths(self):
        response = self.client.get("/openapi.json")
        paths = response.json()["paths"]
        self.assertIn("/contacts/", paths)
        self.assertIn("/contacts/{contact_id}", paths)

    def test_openapi_has_schemas(self):
        response = self.client.get("/openapi.json")
        schemas = response.json()["components"]["schemas"]
        self.assertIn("ContactCreate", schemas)
        self.assertIn("ContactResponse", schemas)

    def test_openapi_has_api_title(self):
        response = self.client.get("/openapi.json")
        info = response.json()["info"]
        self.assertEqual(info["title"], "Contact Manager API")
        self.assertEqual(info["version"], "1.0.0")


if __name__ == "__main__":
    unittest.main()
