# Contact Manager API - Documentation

## Overview
This API manages contacts with full CRUD operations, input validation, and proper error handling.

## Accessing the Documentation

### Swagger UI (Interactive)
Open your browser and go to: `http://127.0.0.1:8000/docs`

Swagger UI lets you try out each endpoint directly from the browser. You can fill in parameters, send requests, and see the responses.

### ReDoc (Read-only)
Open your browser and go to: `http://127.0.0.1:8000/redoc`

ReDoc provides a clean, readable version of the API documentation.

### OpenAPI JSON
The raw OpenAPI specification is available at: `http://127.0.0.1:8000/openapi.json`

## Endpoints

### GET /contacts
Returns a list of all contacts.

**Response**: `200 OK`
```json
[
    {"id": 1, "name": "John Doe", "email": "john@example.com", "phone": "1234567890"}
]
```

### GET /contacts/{id}
Returns a single contact by ID.

**Response**: `200 OK` or `404 Not Found`

### POST /contacts
Creates a new contact.

**Request Body**:
```json
{"name": "John Doe", "email": "john@example.com", "phone": "1234567890"}
```

**Response**: `201 Created`

### PUT /contacts/{id}
Updates an existing contact.

**Request Body**: Same as POST.

**Response**: `200 OK` or `404 Not Found`

### DELETE /contacts/{id}
Deletes a contact.

**Response**: `200 OK` or `404 Not Found`

## Error Responses
All errors return JSON with a `detail` field:
```json
{"detail": "Contact with id 999 not found"}
```

- `400` - Invalid input (bad email, missing fields, etc.)
- `404` - Resource not found
- `500` - Internal server error
